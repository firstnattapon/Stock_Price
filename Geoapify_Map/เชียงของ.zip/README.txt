Rent_Gradient bundle.zip
- manifest.json: compatibility & policy
- config/config.json: user settings + precomputed results
- cache/cache.zip: OSM graph cache archive
